export const FETCH_MEMBER = 'FETCH_MEMBER'

export const REGISTER = 'REGISTER'
export const LOGIN = 'LOGIN'
export const LOGOUT = 'LOGOUT'
export const UPDATE_PROFILE = 'UPDATE_PROFILE'

export const EIGHT = 'EIGHT'
export const OBJ = 'OBJ'
