import React from 'react'
import PropTypes from 'prop-types'

class Notfound extends React.Component {
  render () {
    return(
      <div>404 not found</div>
    );
  }
}

export default Notfound;
