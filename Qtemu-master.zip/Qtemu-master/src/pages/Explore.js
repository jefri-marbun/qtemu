import React from 'react'
import PropTypes from 'prop-types'

class Explore extends React.Component {
  render () {
    return (
      <div>ini ceritanya halaman Explore</div>
    );
  }
}

export default Explore;
