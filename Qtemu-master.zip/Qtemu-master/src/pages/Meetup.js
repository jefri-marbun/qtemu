import React from 'react'
import PropTypes from 'prop-types'

class Meetup extends React.Component {
  render () {
    return (
      <div>ini ceritanya halaman meetup</div>
    );
  }
}

export default Meetup;
