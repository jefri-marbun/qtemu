import DetailProfile from './DetailProfile';
import DetailMember from './DetailMember';
import NavbarWrap from './NavbarWrap';

export {
    DetailProfile,
    NavbarWrap,
    DetailMember
}
