import * as UserActionCreator from './User';

export {
	UserActionCreator,
};
